#include "osoba.h"

