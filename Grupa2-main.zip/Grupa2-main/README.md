# Grupa2: Završni projekat iz predmeta Objetkno orijentisano programiranje
Ovaj program je višenamjenski, namijenjen je putnicima koji se koriste avio prevozom, avio kompanijama (agencijama), kao i zaposlenicima aerodoroma. Prilikom pristupa programu potrebno je izabrati mode pristupa u zavisnosti od načina korištenja usluga. Postoje tri mode-a za putnike, radnike i agenciju. Putnicima je omogućena kupovina karte gdje je potrebno da popune svoje lične podatke o krati, te o destinaiciji koju žele posjetiti. Nakon popunjavanjua obrasca tu je txt. fajl sa svim podacima o njihovom putovanju. Radnicima aerodroma je  omogućen uvid u spisak putnika i u bilo kojem trenutku se može promijeniti mode rada programa. Dok agencija  može vidjeti spisak putnika, mogu mijenjati mode i unijeti podatke o agenciji.

Napomena!
Prilikom pokretanja našeg projekta u DEV C++ programu potrebno je korigovati opcije kompajlera u -std=c++11,ako bude nekih problema molimo Vas da javite nekom od članova grupe.
