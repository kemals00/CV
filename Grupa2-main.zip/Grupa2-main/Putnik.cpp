#include "Putnik.h"
#include<iostream>
#include<cstring>
#include<fstream>
#include <ctime>
#include <memory>
#include <time.h> 
#include "Agencija.h"
#include <iomanip>
#include "Funkcije.h"
void Putnik::setIme()
{
	std::cout << "\n\tUnesite ime: ";
	std::cin >> ime;
	bool provjera = true;

	while (provjera)
	{
		for (int i = 0; i < this->ime.length(); i++)//provjera da li je ime bez brojeva
		{
			if (isdigit(this->ime.at(i)))
			{
				std::cout << "\n\tIme ne moze sadrzavati brojeve u sebi!\n";
				std::cout << "\n\tPonovite unos: ";
				std::getline(std::cin, this->ime);
				provjera = true;
				break;
			}
			else
			{
				provjera = false;
			}
		}
	}

	for (int i = 0; i < this->ime.length(); i++)//postavljanje da je uvijek pocetno slovo veliko
	{
		if (i == 0)
		{
			if (this->ime.at(i) >= 97 && this->ime.at(i) <= 122)
			{
				this->ime.at(i) = this->ime.at(i) - 32;
			}
		}
		else
		{
			if (this->ime.at(i) >= 65 && this->ime.at(i) <= 90)
			{
				this->ime.at(i) = this->ime.at(i) + 32;
			}
		}

	}
}

void Putnik::setPrezime()
{
	std::cout << "\tUnesite prezime: ";
	std::cin >> prezime;
	bool provjera = true;

	while (provjera)
	{
		for (int i = 0; i < this->prezime.length(); i++)
		{
			if (isdigit(this->prezime.at(i)))
			{
				std::cout << "\n\tPrezime ne moze sadrzavati brojeve u sebi!\n";
				std::cout << "\n\tPonovite unos: ";
				std::getline(std::cin, this->prezime);
				provjera = true;
				break;
			}
			else
			{
				provjera = false;
			}
		}
	}

	for (int i = 0; i < this->prezime.length(); i++)
	{
		if (i == 0)
		{
			if (this->prezime.at(i) >= 97 && this->prezime.at(i) <= 122)
			{
				this->prezime.at(i) = this->prezime.at(i) - 32;
			}
		}
		else
		{
			if (this->prezime.at(i) >= 65 && this->prezime.at(i) <= 90)
			{
				this->prezime.at(i) = this->prezime.at(i) + 32;
			}
		}

	}
}

void Putnik::setBrPasosa()
{
	std::cout << "\tUneiste broj pasosa: ";
	std::cin >> brPasosa;
}

void Putnik::setPlacanje()
{
	std::shared_ptr<int> x = std::make_shared<int>();
	std::cout << "\n\t\tNACIN PLACANJA\n";
	std::cout << "\n\t1. Karticno\n\t2. Gotovinsko\n\t3. Na rate\n";
	do {
		std::cout << "\n\tIzaberite nacin placanja: ";
		std::cin >> *x;
	} while (*x < 1 || *x > 3);
	std::cin.ignore();
	this->placanje = Placanje(*x);
}

std::string Putnik::getIme()
{
	return this->ime;
}

std::string Putnik::getPrezime()
{
	return this->prezime;
}

std::string Putnik::getBrPasosa()
{
	return this->brPasosa;
}

Placanje Putnik::getPlacanje()
{
	return this->placanje;
}

void Putnik::postaviPutnik()
{
	std::cout << "\n\t\tPODACI O PUTNIKU\n";
	this->setIme();
	this->setPrezime();
	this->setBrPasosa();
	this->setPlacanje();
	this->postaviKarta();
	this->adresa.postaviAdresu();
}

void Putnik::citajInfo()
{
	Agencija a;
	system("cls");
	std::cout << "\n====================================================================\n";
	std::cout << "Podaci o agenciji\n";
	std::cout << "\n\t\tINFORMACIJE O AGENCIJI";
	std::cout << "\n\n\tPutujte sa " << a.getNaziv() << " \n";
	std::cout << "\n\tO nama: \n\t";
	int brojac = 1;
	for(int i = 0; i < a.getOpis().length(); i++){
		std::cout << a.getOpis().at(i);
		if (i >= brojac * 50 && a.getOpis().at(i)==32) {
			std::cout << "\n\t";
			brojac++;
		}
	}
	std::cout << "\n\n\n\tKontakt telefon: " << a.tel;
	std::cout << "\n\tVise informacija potrazite u info.txt";
	std::cout << "\n\n====================================================================\n";
	std::cout << "\tZa ugodan let potrudit ce se osoblje " << a.getNaziv();
	std::cout << "\n====================================================================\n";
}

Putnik::Putnik()
{
	this->brPasosa = "nema unosa";
	Adresa();
}

void Putnik::otkaziLet(){
	std::cout<<"Let je otkazan.";
}

std::ostream& operator<<(std::ostream& os, const Putnik& p)
{
	os<<"Ime: "<<p.ime<<"\n"<<"Prezime: "<<p.prezime;
	return os;
}
void Putnik::setBrKarta()
{
	srand(time(NULL));
	this->brKarta = rand() % 999999 + 100000;
}
int Putnik::getBrKarta()
{
	return this->brKarta;
}
void Putnik::setDatumLeta()
{
	std::cout << "\n\tUnesite datum i vijeme leta: ";
	std::getline(std::cin, this->datumLeta);
}
std::string Putnik::getDatumLeta()
{
	return this->datumLeta;
}
void Putnik::setKlasa()
{
	std::shared_ptr<int> x = std::make_shared<int>();
	std::cout << "\n\t\tKLASA NA LETU\n";
	std::cout << "\n\t1. Ekonomska\n\t2. Biznis\n\t3. Prva\n";
	do {
		std::cout << "\n\n\tIzaberite klasu na svom letu: ";
		std::cin >> *x;
	} while (*x < 1 || *x > 3);
	std::cin.ignore();
	this->klasa = Klasa(*x);
}
Klasa Putnik::getKlasa()
{
	return this->klasa;
}
void Putnik::setDestinacija()
{
	std::shared_ptr<int> x = std::make_shared<int>();
	std::cout << "\n\t\tDESTINACIJA ZA PUTOVANJE\n";
	std::cout << "\n\t1. Berlin\n\t2. Moskva\n\t3. Budimpesta\n\t4. Istanbul\n\t5. Zagreb\n\t6. Lisabon\n\t7. Ankara\n\t8. Rim\n";
	do {
		std::cout << "\n\n\tIzaberite destinaciju putovanja: ";
		std::cin >> *x;
	} while (*x < 1 || *x > 8);
	switch(*x){
		case 1:
			cijena = 1032.65 * koeficijent;
			break;
		case 2:
			cijena = 1898.38 * koeficijent;
			break;
		case 3:
			cijena = 408.12 * koeficijent;
			break;
		case 4: 
			cijena = 923 * koeficijent;
			break;
		case 5:
			cijena = 290.49 * koeficijent;
			break;
		case 6:
			cijena = 2359.66 * koeficijent;
			break;
		case 7:
			cijena = 1270.69 * koeficijent;
			break;
		case 8:
			cijena = 530.72 *koeficijent;
			break;
	}
	std::cin.ignore();
	this->destinacija = Destinacija(*x);

}

Destinacija Putnik::getDestinacija()
{
	return this->destinacija;
}

void Putnik::postaviKarta()
{
	std::cout << "\n\t\tPODACI ZA KARTU\n\n";
	this->setBrKarta();
	this->setKlasa();
	this->setDestinacija();
	this->setDatumLeta();
}

void Putnik::kupiKartu()
{
	system("cls");
	postaviPutnik();
	std::ofstream karta("karta.txt");
	time_t now=time(0);			//funkcije za racunanje vemena
    tm *ltm=localtime(&now);
	karta << "\n====================================================================\n";
	karta << "Datum kupovine:	" << ltm->tm_mday << "." << 1+ltm->tm_mon << "." << 1900+ltm->tm_year<< ".\t\t";
	karta << "Vrijeme kupovine: " << 1+ltm->tm_hour << ":" << 1+ltm->tm_min << ":" << 1+ltm->tm_sec << "\n";
	karta << "\n\t\t\tKARTA";
	karta << "\n\n\t\tPodaci o putniku: \n";
	karta << "\n\tIme i prezime: " << getIme() << " " << getPrezime();
	karta << "\n\tBroj pasosa: " << getBrPasosa();
	karta << "\n\tNacin placanja: ";
		if (getPlacanje() == 1) karta << "karticno\n";
		else if (getPlacanje() == 2) karta << "gotovinsko\n";
		else karta << "na rate\n";
	karta << "\n\n\t\t\t Broj karte: " << getBrKarta();
	karta << "\n\n\tDestinacija: ";
		switch(getDestinacija()){
			case 1:
				karta << "Berlin";
				break;
			case 2:
				karta << "Moskva";
				break;
			case 3:
				karta << "Budimpesta";
				break;
			case 4:
				karta << "Istanbul";
				break;
			case 5:
				karta << "Zagreb";
				break;
			case 6:
				karta << "Lisabon";
				break;
			case 7:
				karta << "Ankara";
				break;
			case 8:
				karta << "Rim";
				break;
		}
	karta << "\n\tDatum Vaseg leta: " << getDatumLeta();
	karta << "\n\tKlasa: ";
		if (getKlasa() == 1) karta << "ekonomska\n";
		else if (getKlasa() == 2) karta << "biznis\n";
		else karta << "prva\n";
	karta << "\n\tCijena Vase karte: " << cijena << " KM";
	karta << "\n\n\tU slucaju da prtljag izgubite na aerodromu, \n\ton ce Vam biti poslan na adresu koju ste unijeli.\n";
	karta << "\n\tUlica i broj: " << this->adresa.getUlica() << " " << this->adresa.getBroj();
	karta << "\n\tGrad, drzava: " << this->adresa.getPostanskiBr() << " " << this->adresa.getGrad() << ", " << this->adresa.getDrzava();
	karta << "\n\n\n====================================================================\n";
	karta << "\n\tZelimo Vam sretan put i ugodan let. Vasa agencija\n";
	karta << "\n====================================================================\n";
	std::cout << "Karta je uspjesno rezervisana.";
	karta.close();
	std::ofstream lista("lista.txt");
	lista << "\n====================================================================\n";
	lista << "\n\n\t\tLista putnika: \n";
	lista << "\n\tIme i prezime: " << this->getIme() << " " << this->getPrezime();
	lista << "\n\tBroj pasosa: " << this->getBrPasosa();	
	lista << "\n====================================================================\n";
	lista.close();
	std::ofstream spisak("spisak.txt", std::ios::app);
	spisak << std::left << std::setw(20) << this->getIme();
	spisak << std::left << std::setw(20) << this->getPrezime();
	spisak << std::left << std::setw(12) << this->getBrPasosa();
	spisak.close();
	void IzaberiMode();
}

