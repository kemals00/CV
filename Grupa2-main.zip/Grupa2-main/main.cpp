//Grupa 2
//Projekat iz predmeta OOP
#include <iostream>
#include "Funkcije.h"
using std::cout;
using std::cin;
//sifra za pristup radniku aerodroma: 5678
//sifra za pristup agenciji: 1234
//Putnik pristupa bez sifre

int main() {
	setlocale(LC_ALL, " ");
	
	IzaberiMode();
	system("PAUSE");
	return 0;
}
